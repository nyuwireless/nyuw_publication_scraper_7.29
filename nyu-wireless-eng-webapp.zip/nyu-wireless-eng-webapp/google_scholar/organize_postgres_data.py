import psycopg2
import json
from bs4 import BeautifulSoup
import os

DATABASE_URL = "postgres://ub8vgi6fgo11u2:p0ec387f77e7d023d34483bedbcbd1a4d29d2d49d4ea12d0ad930064ec8590410@cd5gks8n4kb20g.cluster-czrs8kj4isg7.us-east-1.rds.amazonaws.com:5432/d4femoomgkjt3h"
HTML_FORMS_DIRECTORY = 'html_forms'
ORGANIZED_DATA_DIRECTORY = 'organized_data'
FACULTY_SCRAPES_DIRECTORY = 'faculty_scrapes'

# Create the organized_data directory if it doesn't exist
if not os.path.exists(ORGANIZED_DATA_DIRECTORY):
    os.makedirs(ORGANIZED_DATA_DIRECTORY)

# Function to fetch data from the PostgreSQL database
def fetch_data():
    conn = psycopg2.connect(DATABASE_URL, sslmode='require')
    cur = conn.cursor()
    cur.execute("SELECT jsonb_pretty(data) FROM submissions")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return [json.loads(row[0]) for row in rows]

# Function to clean JSON data
def clean_json_data(data):
    cleaned_data = {}
    for key, value in data.items():
        if isinstance(value, list):
            if any(value):
                cleaned_data[key] = value
        elif value:
            cleaned_data[key] = value
    return cleaned_data

# Function to read the HTML form from a file
def read_html_form(form_id):
    file_path = os.path.join(HTML_FORMS_DIRECTORY, f"{form_id}_form.html")
    with open(file_path, 'r') as file:
        html_form = file.read()
    return html_form

# Function to read the original JSON data from a file
def read_original_json_data(form_id):
    file_path = os.path.join(FACULTY_SCRAPES_DIRECTORY, f"{form_id}.json")
    with open(file_path, 'r') as file:
        original_json_data = json.load(file)
    return original_json_data

# Function to organize data based on form structure
def organize_data(response_data, html_form, original_json_data):
    # Clean the JSON data
    cleaned_data = clean_json_data(response_data)
    
    # Parse the HTML form to extract question titles
    soup = BeautifulSoup(html_form, 'html.parser')
    questions = soup.find_all('div')
    
    organized_data = []

    for question in questions:
        title = question.find('p').text
        question_number = question.find('input')['name'].split('_')[1]
        
        categories = cleaned_data.get(f'question_{question_number}', [])
        other = cleaned_data.get(f'other_{question_number}', '')
        
        question_data = {
            "Title": title,
            "Categories": categories,
            "Other": other
        }

        # Add additional fields from the original JSON data
        additional_fields = original_json_data[int(question_number)]
        question_data.update(additional_fields)
        
        organized_data.append(question_data)
    
    return organized_data

# Function to save organized data as JSON
def save_organized_data(form_id, organized_data):
    output_filename = os.path.join(ORGANIZED_DATA_DIRECTORY, f"{form_id}_organized.json")
    with open(output_filename, 'w') as file:
        json.dump(organized_data, file, indent=4)
    print(f"Organized data for {form_id} saved successfully!")

# Fetch data from the database
submissions = fetch_data()

# Process and organize each submission
for submission in submissions:
    form_id = submission['form_id']
    html_form = read_html_form(form_id)
    original_json_data = read_original_json_data(form_id)
    organized_data = organize_data(submission, html_form, original_json_data)
    save_organized_data(form_id, organized_data)
    for item in organized_data:
        print(f"Title: {item['Title']}")
        print(f"Categories: {', '.join(item['Categories'])}")
        if item['Other']:
            print(f"Other: {item['Other']}")
        print(f"Link: {item['link']}")
        print(f"Citation ID: {item['citation_id']}")
        print(f"Authors: {', '.join(item['authors'])}")
        print(f"Publication: {item['publication']}")
        print(f"Year: {item['year']}")
        print("\n")
