import psycopg2
import json
import glob
import os

# Hardcoded database URL
DATABASE_URL = "postgres://ub8vgi6fgo11u2:p0ec387f77e7d023d34483bedbcbd1a4d29d2d49d4ea12d0ad930064ec8590410@cd5gks8n4kb20g.cluster-czrs8kj4isg7.us-east-1.rds.amazonaws.com:5432/d4femoomgkjt3h"

# Directory containing JSON files
DATA_DIR = "organized_data"

def connect_to_db():
    try:
        connection = psycopg2.connect(DATABASE_URL)
        return connection
    except Exception as error:
        print("Error connecting to database:", error)
        return None

def create_table(connection):
    create_table_query = """
    CREATE TABLE IF NOT EXISTS publications (
        id SERIAL PRIMARY KEY,
        title TEXT,
        categories JSONB,
        other TEXT,
        link TEXT,
        citation_id TEXT,
        authors TEXT,
        publication TEXT,
        year TEXT
    );
    """
    cursor = connection.cursor()
    cursor.execute(create_table_query)
    connection.commit()
    cursor.close()

def insert_data(connection, json_data):
    insert_query = """
    INSERT INTO publications (title, categories, other, link, citation_id, authors, publication, year)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
    """
    cursor = connection.cursor()
    for record in json_data:
        categories = json.dumps(record["Categories"]) if isinstance(record["Categories"], list) else json.dumps([record["Categories"]])
        cursor.execute(insert_query, (
            record.get("title"),
            categories,
            record.get("Other"),
            record.get("link"),
            record.get("citation_id"),
            record.get("authors"),
            record.get("publication"),
            record.get("year")
        ))
    connection.commit()
    cursor.close()

def load_json_files():
    json_files = glob.glob(os.path.join(DATA_DIR, "*.json"))
    data_list = []
    for json_file in json_files:
        with open(json_file, 'r') as file:
            data = json.load(file)
            data_list.extend(data)
    return data_list

def main():
    connection = connect_to_db()
    if connection:
        create_table(connection)
        json_data_list = load_json_files()
        insert_data(connection, json_data_list)
        connection.close()
        print("Data inserted successfully.")
    else:
        print("Failed to connect to the database.")

if __name__ == "__main__":
    main()
