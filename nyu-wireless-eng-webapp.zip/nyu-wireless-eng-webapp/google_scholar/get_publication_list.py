# ref: https://serpapi.com/google-scholar-author-articles
# ref dashboard: https://serpapi.com/dashboard

from serpapi import GoogleSearch
import json
from urllib.parse import urlsplit, parse_qsl
import os
from datetime import datetime

# Replace with your actual API key
api_key = "4f14ade0b085ab969fa1e1d2cd66d1134a5bd6e1eba293ecfe3824f18e2e2796"

# Replace with the author_ids of the professors
author_ids = ["FXzV5yQAAAAJ", "fzSHXS8AAAAJ", "tBLWIBoAAAAJ", "TmPZ5uEAAAAJ", "UH3qseUAAAAJ","veyAHJgAAAAJ","QhklKroAAAAJ","H6_aG50AAAAJ&hl","byxKG8cAAAAJ&hl","5aKSeI0AAAAJ&hl","41k4_N8AAAAJ&hl","PfKNK8gAAAAJ&hl","KSI2DE0AAAAJ&hl","0Brxa0QAAAAJ&hl","aPlMXLAAAAAJ&hl","W8f0d6oAAAAJ&hl","Iwsb0roAAAAJ&hl","Dew7rE0AAAAJ&hl","uXKSTEIAAAAJ&hl","sNeVyqoAAAAJ&hl","AZ3SaZgAAAAJ&hl","AnALXFcAAAAJ"]

# Parameters for the search
def get_params(author_id, api_key):
    return {
        "engine": "google_scholar_author",
        "author_id": author_id,
        "api_key": api_key,
    }

# Function to get author name
def get_author_name(author_id, api_key):
    author_params = {
        "engine": "google_scholar_author",
        "author_id": author_id,
        "api_key": api_key,
    }
    search = GoogleSearch(author_params)
    results = search.get_dict()
    return results.get("author", {}).get("name", "unknown_author")

# Create directory if it doesn't exist
output_dir = "faculty_scrapes"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Iterate over each author ID
for author_id in author_ids:
    params = get_params(author_id, api_key)
    
    # Get the author's name
    author_name = get_author_name(author_id, api_key).replace(" ", "_")

    # Generate the filename
    date_str = datetime.now().strftime("%Y-%m-%d")
    output_filename = f"{author_name}_{date_str}.json"
    output_filepath = os.path.join(output_dir, output_filename)

    # Collect articles
    author_article_results_data = []

    articles_is_present = True
    next_start = 0

    while articles_is_present:

        params["start"] = next_start

        search = GoogleSearch(params)

        results = search.get_dict()
        
        articles = results.get("articles", [])

        for article in articles:
            # Filter articles from 2012 onwards
            year = article.get("year")
            if year and int(year) >= 2012:
                cleaned_article = {
                    "title": article.get("title"),
                    "link": article.get("link"),
                    "citation_id": article.get("citation_id"),
                    "authors": article.get("authors"),
                    "publication": article.get("publication"),
                    "year": year
                }
                author_article_results_data.append(cleaned_article)

        if "next" in results.get("serpapi_pagination", {}):
            print(f"Next link: {results['serpapi_pagination']['next']}")
            query_params = dict(parse_qsl(urlsplit(results['serpapi_pagination']['next']).query))
            params.update(query_params)
        else:
            articles_is_present = False

        next_start += 20

    # Sort the list by year, from most recent to oldest
    author_article_results_data_sorted = sorted(author_article_results_data, key=lambda x: x.get("year", "0"), reverse=True)

    # Write the sorted list to a file
    with open(output_filepath, "w") as outfile:
        json.dump(author_article_results_data_sorted, outfile, indent=4)  # Using indent for better readability

    print(f"Data for {author_name} saved to {output_filepath}")