import json
import os

# Directory containing JSON files
json_directory = 'faculty_scrapes'
# Directory to save HTML forms
html_forms_directory = 'html_forms'

# Create the html_forms directory if it doesn't exist
if not os.path.exists(html_forms_directory):
    os.makedirs(html_forms_directory)

# HTML template with placeholders
html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publication Classification Form</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 20px;
            line-height: 1.6;
        }}
        h1 {{
            text-align: center;
        }}
        p {{
            margin-bottom: 20px;
        }}
        .form-section {{
            margin-bottom: 20px;
        }}
        .form-section p {{
            font-weight: bold;
        }}
        .form-section div {{
            margin-bottom: 10px;
        }}
        button {{
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }}
        button:hover {{
            background-color: #0056b3;
        }}
    </style>
    <script>
        // Save individual field data to local storage
        function saveField(fieldId) {{
            var field = document.getElementById(fieldId);
            var fieldType = field.type;
            if (fieldType === 'checkbox') {{
                localStorage.setItem(fieldId, field.checked);
            }} else {{
                localStorage.setItem(fieldId, field.value);
            }}
        }}

        // Load individual field data from local storage
        function loadField(fieldId) {{
            var field = document.getElementById(fieldId);
            var fieldType = field.type;
            if (fieldType === 'checkbox') {{
                field.checked = (localStorage.getItem(fieldId) === 'true');
            }} else {{
                field.value = localStorage.getItem(fieldId) || '';
            }}
        }}

        // Load all field data on page load
        function loadFormData() {{
            var form = document.forms[0];
            for (var i = 0; i < form.elements.length; i++) {{
                var element = form.elements[i];
                if (element.type === 'checkbox' || element.type === 'text') {{
                    loadField(element.id);
                }}
            }}
        }}

        // Add save event to each form field on page load
        function addSaveEvent() {{
            var form = document.forms[0];
            for (var i = 0; i < form.elements.length; i++) {{
                var element = form.elements[i];
                if (element.type === 'checkbox' || element.type === 'text') {{
                    element.onchange = function() {{ saveField(this.id); }};
                }}
            }}
        }}

        window.onload = function() {{
            loadFormData();
            addSaveEvent();
        }};
    </script>
</head>
<body>
    <h1>Publication Classification Form</h1>
    <p>The purpose of this form is to classify all publications for NYU Wireless's updated publication library. Each research paper should be classified by one or more of our 6 overarching research areas: Wireless Communications and Sensing; AI/ML in Wireless; Applications; Circuits and Devices; Networking, Edge Computing, and Security; Testbeds and Prototypes. If the title listed is not something that should be included in the NYU Wireless publication database then please select "Do not include".</p>
    <p>The "Other" checkbox can be used to further classify each research paper if one or more of the 6 research areas does not provide a specific enough classification. On the front-end of the Publication Library application, users will be able to use a keyword search feature; entries to this "Other" category will be linked to this keyword search feature. Please enter any inputs to this checkbox in comma separated format ex: "sustainability, mmwave, latency" etc.</p>
    <form id="{form_id}" action="https://nyu-wireless-pub-scraper-7e0ee778694b.herokuapp.com/submit" method="post">
        <input type="hidden" name="form_id" value="{form_id}">
        {questions}
        <button type="submit">Submit</button>
    </form>
</body>
</html>
"""

# Checkbox options
checkbox_options = [
    "Wireless Communications and Sensing",
    "Applications",
    "Networking Edge Computing and Security",
    "Testbeds and Prototypes",
    "Artificial Intelligence and Machine Learning in Wireless",
    "Circuits and Devices",
    "Do not include"
]

# Function to generate HTML form for a given JSON file
def generate_html_form(json_file):
    with open(json_file, 'r') as file:
        publications = json.load(file)
    
    # Generate HTML for questions
    questions_html = ""
    for idx, pub in enumerate(publications):
        question_html = f"<div class='form-section'><p><a href='{pub['link']}' target='_blank'>{pub['title']}</a></p>"
        for option in checkbox_options:
            checkbox_id = f"question_{idx}_{option.replace(' ', '_')}"
            question_html += f'<label><input type="checkbox" id="{checkbox_id}" name="question_{idx}" value="{option}" onchange="saveField(\'{checkbox_id}\')"> {option}</label><br>'
        other_text_id = f"other_{idx}"
        question_html += f'<label><input type="checkbox" id="question_{idx}_other" name="question_{idx}" value="other" onchange="saveField(\'question_{idx}_other\')"> Other: <input type="text" id="{other_text_id}" name="other_{idx}" onchange="saveField(\'{other_text_id}\')"></label><br>'
        question_html += "</div>"
        questions_html += question_html
    
    # Get the form ID from the JSON file name
    form_id = os.path.splitext(os.path.basename(json_file))[0]
    
    # Combine HTML template with questions and form ID
    html_output = html_template.format(form_id=form_id, questions=questions_html)
    
    # Write HTML to file in the html_forms directory
    output_filename = os.path.join(html_forms_directory, f"{form_id}_form.html")
    with open(output_filename, 'w') as file:
        file.write(html_output)
    
    print(f"HTML form for {json_file} generated successfully!")

# Iterate over all JSON files in the directory
for filename in os.listdir(json_directory):
    if filename.endswith('.json'):
        generate_html_form(os.path.join(json_directory, filename))
