document.addEventListener('DOMContentLoaded', () => {
    const searchBar = document.getElementById('searchBar');
    const resultsContainer = document.getElementById('results');

    // Load all JSON files from the faculty_scrapes folder
    const jsonFiles = ['Elza_Erkip_2024-06-20.json', 'Sundeep_Rangan_2024-06-20.json', 'Thomas_Marzetta_2024-06-20.json', 'Dennis_Shasha_2024-06-20.json','Shivendra_S_Panwar_2024-06-20.json','JR_(John-Ross)_Rizzo_2024-06-20.json' ]; // Add all your JSON files here
    let allPublications = [];

    // Fetch data from JSON files
    jsonFiles.forEach(file => {
        fetch(`faculty_scrapes/${file}`)
            .then(response => response.json())
            .then(data => {
                allPublications = allPublications.concat(data);
            })
            .catch(error => console.error('Error loading JSON file:', error));
    });

    searchBar.addEventListener('input', (event) => {
        const query = event.target.value.toLowerCase();
        const filteredPublications = allPublications.filter(pub => 
            pub.title.toLowerCase().includes(query) ||
            pub.authors.toLowerCase().includes(query) ||
            pub.year.includes(query)
        );

        displayResults(filteredPublications);
    });

    function displayResults(publications) {
        resultsContainer.innerHTML = '';

        publications.forEach(pub => {
            const div = document.createElement('div');
            div.classList.add('result-item');

            const title = document.createElement('h2');
            title.textContent = pub.title;

            const authors = document.createElement('p');
            authors.textContent = `Authors: ${pub.authors}`;

            const year = document.createElement('p');
            year.textContent = `Year: ${pub.year}`;

            const link = document.createElement('a');
            link.href = pub.link;
            link.textContent = 'View Publication';
            link.target = '_blank';

            div.appendChild(title);
            div.appendChild(authors);
            div.appendChild(year);
            div.appendChild(link);

            resultsContainer.appendChild(div);
        });
    }
});
