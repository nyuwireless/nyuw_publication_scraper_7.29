from flask import Flask, request, jsonify
import psycopg2
import os
import json
import logging

app = Flask(__name__)

DATABASE_URL = "postgres://ub8vgi6fgo11u2:p0ec387f77e7d023d34483bedbcbd1a4d29d2d49d4ea12d0ad930064ec8590410@cd5gks8n4kb20g.cluster-czrs8kj4isg7.us-east-1.rds.amazonaws.com:5432/d4femoomgkjt3h"

def get_db_connection():
    conn = psycopg2.connect(DATABASE_URL, sslmode='require')
    return conn

@app.route('/')
def index():
    return "Welcome to the Publication Form Submission App!"

@app.route('/submit', methods=['POST'])
def submit():
    try:
        data = request.form.to_dict(flat=False)  # Use flat=False to get lists of values for each key
        app.logger.info(f"Form data received: {data}")
        
        form_id = data.pop('form_id', [None])[0]  # Extract form ID
        if not form_id:
            raise KeyError('form_id')
        
        app.logger.info(f"Form ID: {form_id}")
        
        for key in data:
            if len(data[key]) == 1:
                data[key] = data[key][0]
        
        data['form_id'] = form_id  # Include form ID in the data
        app.logger.info(f"Processed data: {data}")
        
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("INSERT INTO submissions (data) VALUES (%s)", (json.dumps(data),))
        conn.commit()
        cur.close()
        conn.close()
        
        return "Thank you for your submission!"
    except Exception as e:
        app.logger.error(f"Error processing form: {e}")
        return "Internal Server Error", 500

if __name__ == '__main__':
    app.run(debug=True)
